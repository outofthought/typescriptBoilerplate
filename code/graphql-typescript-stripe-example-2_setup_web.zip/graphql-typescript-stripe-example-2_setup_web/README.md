# graphql-typescript-stripe-example
An example project of how to use Stripe with GraphQL and Typescript

0. Architecture
1. Server
2. Frontend
3. Stripe checkout and sign user up for subcription
4. How to handle free trials
5. Nav bar
6. Change credit card
7. Cancel or resubscribe
8. Styled Components
